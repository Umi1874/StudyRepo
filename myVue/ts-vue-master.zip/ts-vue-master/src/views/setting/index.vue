<template>
  <div>个人设置</div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
@Component({
  name: "Setting"
})
export default class extends Vue {}
</script>