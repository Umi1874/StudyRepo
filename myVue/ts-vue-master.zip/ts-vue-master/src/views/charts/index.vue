<template>
  <div>图表</div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
@Component({
  name: "Account"
})
export default class extends Vue {}
</script>