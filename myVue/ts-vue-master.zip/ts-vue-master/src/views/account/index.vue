<template>
  <div>账户列表页</div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
@Component({
  name: "Account"
})
export default class extends Vue {}
</script>
