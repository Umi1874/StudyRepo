import express from "express";
import bodyParser from "body-parser";
import compression from "compression";
import morgan from "morgan";
import cors from "cors";
import http from "http";
import path from "path";
import yaml from "yamljs";

// TODO: 后期mock接入
